#pragma once

class $safeitemname$
{

public:
	$safeitemname$();
	~$safeitemname$();

protected:
	$safeitemname$(const $safeitemname$& _other) = delete;
	$safeitemname$($safeitemname$&& _other) noexcept;

private:
	$safeitemname$& operator=(const $safeitemname$& _other) = delete;
	$safeitemname$& operator=(const $safeitemname$&& _other) = delete;


};

