#include "PreCompile.h"
#include "$safeitemname$.h"

$safeitemname$::$safeitemname$()
{
}

$safeitemname$::$safeitemname$($safeitemname$&& _other) noexcept
{
}

$safeitemname$::~$safeitemname$()
{
}