#pragma once

class $fileinputname$;
class $fileinputname$Manager
{
	static $fileinputname$Manager* inst_;
	std::map<std::string, $fileinputname$*> resourceMap_;


private:
	$fileinputname$Manager();
	~$fileinputname$Manager();

protected:
	$fileinputname$Manager(const $fileinputname$Manager& _other) = delete;
	$fileinputname$Manager($fileinputname$Manager&& _other) = delete;

private:
	$fileinputname$Manager& operator=(const $fileinputname$Manager& _other) = delete;
	$fileinputname$Manager& operator=(const $fileinputname$Manager&& _other) = delete;

public:
	$fileinputname$* Create(const std::string& _name);							
	$fileinputname$* Load(const std::string& _path);							
	$fileinputname$* Load(const std::string& _name, const std::string& _path);	
	$fileinputname$* Find(const std::string& _name);							

public:
	static $fileinputname$Manager& GetInst()
	{
		return *inst_;
	}

	static void Destroy()
	{
		if (nullptr != inst_)
		{
			delete inst_;
			inst_ = nullptr;
		}
	}

};

