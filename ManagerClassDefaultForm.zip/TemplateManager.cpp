#include "PreCompile.h"
#include "$fileinputname$.h"
#include "$fileinputname$Manager.h"

$fileinputname$Manager* $fileinputname$Manager::inst_ = new $fileinputname$Manager();

$fileinputname$Manager::$fileinputname$Manager() : resourceMap_()
{
}

$fileinputname$Manager::~$fileinputname$Manager()
{
    for (const std::pair<std::string, $fileinputname$*>& res : resourceMap_)
    {
        if (nullptr != res.second)
        {
            delete res.second;
        }
    }
    resourceMap_.clear();
}

$fileinputname$* $fileinputname$Manager::Create(const std::string& _name)
{
    if (nullptr != Find(_name))
    {
        GameEngineDebug::MsgBoxError("������ �̹� �����Ǿ��ֽ��ϴ�.");
        return nullptr;
    }

    $fileinputname$* newRes = new $fileinputname$();
    if (nullptr == newRes)
    {
        GameEngineDebug::MsgBoxError("���� ���� ����.");
        delete newRes;
        return nullptr;
    }
    newRes->SetName(_name);

    //���⿡ �ڵ带 ��������.

    resourceMap_.insert(std::map<std::string, $fileinputname$*>::value_type(_name, newRes));
    return newRes;
}

$fileinputname$* $fileinputname$Manager::Load(const std::string& _path)
{
    return Load(GameEnginePath::GetFileName(_path), _path);
}

$fileinputname$* $fileinputname$Manager::Load(const std::string& _name, const std::string& _path)
{
    if (nullptr != Find(_name))
    {
        GameEngineDebug::MsgBoxError("������ �̹� �ε�Ǿ��ֽ��ϴ�.");
        return nullptr;
    }

    $fileinputname$* newRes = new $fileinputname$();
    if (nullptr == newRes)
    {
        GameEngineDebug::MsgBoxError("���� �ε� ����.");
        delete newRes;
        return nullptr;
    }
    newRes->SetName(_name);

    //���⿡ �ڵ带 ��������.

    resourceMap_.insert(std::map<std::string, $fileinputname$*>::value_type(_name, newRes));
    return newRes;
}

$fileinputname$* $fileinputname$Manager::Find(const std::string& _name)
{
    std::map<std::string, $fileinputname$*>::iterator findIter = resourceMap_.find(_name);
    if (resourceMap_.end() == findIter)
    {
        return nullptr;
    }
    else
    {
        return findIter->second;
    }

}